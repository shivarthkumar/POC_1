package EXCEL_IO;
//This class contains a test data template (the fields which a test data contains are member variables in the class)
public class test_data 
{

	String tc_id;
	String first_name;
	String last_name;
	String email;
	String password;
	String address;
	String city;
	String state;
	String postal_code;
	String country;
	String mobile_no;
	String address_alias;
	String expected_result;
	//Constructor initializes a test data
	public test_data(String tc_id, String first_name, String last_name, String email, String password, String address,
			String city, String state, String postal_code, String country, String mobile_no, String address_alias,String expected_result)
	{
		super();
		this.tc_id = tc_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.email = email;
		this.password = password;
		this.address = address;
		this.city = city;
		this.state = state;
		this.postal_code = postal_code;
		this.country = country;
		this.mobile_no = mobile_no;
		this.address_alias = address_alias;
		this.expected_result=expected_result;
	}
	public String getTc_id() {
		return tc_id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public String getEmail() {
		return email;
	}
	public String getPassword() {
		return password;
	}
	public String getAddress() {
		return address;
	}
	public String getCity() {
		return city;
	}
	public String getState() {
		return state;
	}
	public String getPostal_code() {
		return postal_code;
	}
	public String getCountry() {
		return country;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public String getAddress_alias() {
		return address_alias;
	}
	public String getExpected_result() {
		return expected_result;
	}
	
}
