package EXCEL_IO;
//This class contains methods for performing operations in an Excel file such as reading data from excel and writing data into excel

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javafx.scene.input.DataFormat;

public class excel_operations 
{
	//read_Excel reads data from Excel File on the basis of rowIndex given as inputParameter
	public static test_data readExcel(int rowIndex) 
	{
		try {
			//
			File f=new File("C:\\\\Users\\\\anmol.srivastava\\\\Desktop\\\\POC_1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook workbook =new XSSFWorkbook(fis);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			XSSFRow row =sheet.getRow(rowIndex);
			DataFormatter df=new DataFormatter();
			List<XSSFCell> cell_list=new ArrayList<>();
			for(int i=0;i<13;i++) 
			{
				cell_list.add(row.getCell(i));
			}
			String tc_id =df.formatCellValue(cell_list.get(0));
			String first_name=df.formatCellValue(cell_list.get(1));
			String last_name=df.formatCellValue(cell_list.get(2));
			String email=df.formatCellValue(cell_list.get(3));
			String password=df.formatCellValue(cell_list.get(4));
			String address=df.formatCellValue(cell_list.get(5));
			String city=df.formatCellValue(cell_list.get(6));
			String state=df.formatCellValue(cell_list.get(7));
			String postal_code=df.formatCellValue(cell_list.get(8));
			String country=df.formatCellValue(cell_list.get(9));
			String mobile_no=df.formatCellValue(cell_list.get(10));
			String address_alias=df.formatCellValue(cell_list.get(11));
			String expected_result=df.formatCellValue(cell_list.get(12));
			test_data td=new test_data(tc_id,first_name,last_name,email,password,address,city,state,postal_code,country,mobile_no,address_alias,expected_result);
			return td;
			
	     	}
		catch(Exception e) 
		{
			e.printStackTrace();
			return null;
		}
		
		
		
	}
  //writeTestResults write test_results into an Excel File 
  //The row in which data is to be inserted and the data to be inserted are given as input parameters
	public static void writeTestResult(String result,int rowIndex) 
	{
		
		try 
		{
			File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\POC_1.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook workbook=new XSSFWorkbook(fis);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			XSSFRow row=sheet.getRow(rowIndex);
			XSSFCell actual_result_cell=row.createCell(14);
			actual_result_cell.setCellValue(result);
			FileOutputStream fos=new FileOutputStream(f);
			workbook.write(fos);
			
			
			
			
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	//writeActualResult write actualResult obtained after registration into excel file
	
	public static void writeActualResult(String result,int rowIndex) 
	{
		
		try 
		{
			File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\POC_1.xlsx");
			FileInputStream fis =new FileInputStream(f);
			XSSFWorkbook workbook=new XSSFWorkbook(fis);
			XSSFSheet sheet=workbook.getSheet("Sheet1");
			XSSFRow row=sheet.getRow(rowIndex);
			XSSFCell actual_result_cell=row.createCell(13);
			actual_result_cell.setCellValue(result);
			FileOutputStream fos=new FileOutputStream(f);
			workbook.write(fos);
			
			
			
			
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	
	

}
